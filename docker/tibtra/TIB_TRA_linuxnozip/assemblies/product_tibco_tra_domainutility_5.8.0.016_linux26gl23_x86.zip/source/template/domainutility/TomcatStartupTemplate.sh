#!/bin/sh
# -----------------------------------------------------------------------------
# Start Script for the CATALINA Server
# -----------------------------------------------------------------------------

# start of domainUtility modifications
CATALINA_HOME=%CATALINA_HOME%
CONFIG_FILE=%CONFIG_FILE%
TIBCO_TRA_HOME=%TIBCO_TRA_HOME%
TIBCO_DOMAIN_NAME=%TIBCO_DOMAIN_NAME%
TIBCO_DOMAIN_HOME=%TIBCO_DOMAIN_HOME%
TIBCO_RV_HOME=%TIBCO_RV_HOME%
TIBCO_HAWK_HOME=%TIBCO_HAWK_HOME%
TIBCO_TPCL_HOME=%TIBCO_TPCL_HOME%
JAVA_HOME=%JAVA_HOME%
TIBCO_TPCL_LIB_NAME=%TIBCO_TPCL_LIB_NAME%
# end of domainUtility modifications
export CATALINA_HOME CONFIG_FILE TIBCO_TRA_HOME TIBCO_DOMAIN_NAME TIBCO_DOMAIN_HOME TIBCO_RV_HOME TIBCO_HAWK_HOME TIBCO_TPCL_HOME JAVA_HOME TIBCO_TPCL_LIB_NAME

LD_LIBRARY_PATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$LD_LIBRARY_PATH

SHLIB_PATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$SHLIB_PATH

LIBPATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$LIBPATH

CLASSPATH=$JAVA_HOME/lib/tools.jar:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib/icjava621.jar:$TIBCO_TRA_HOME/icjava/6.2/lib/icjava621.jar:$TIBCO_TRA_HOME/hotfix/lib/TIBCrypt.jar:$TIBCO_TRA_HOME/lib/TIBCrypt.jar:$TIBCO_TRA_HOME/../dependency/default/$TIBCO_TPCL_LIB_NAME:$TIBCO_TRA_HOME/../dependency/default/HAWKlib.jar:$TIBCO_TRA_HOME/lib/TIBCOjms.jar:$TIBCO_TRA_HOME/../dependency/default/RVlib.jar:

#Add following options to JAVA_OPTS, if you are using JDK 1.4
#-Djavax.xml.parsers.SAXParserFactory=org.apache.xerces.jaxp.SAXParserFactoryImpl -Djavax.xml.parsers.DocumentBuilderFactory=org.apache.xerces.jaxp.DocumentBuilderFactoryImpl
JAVA_OPTS=" -Xms128m -Xmx512m -DLANG=$LANG -DTIBCO_DOMAIN_NAME=$TIBCO_DOMAIN_NAME -DTIBCO_DOMAIN_HOME=$TIBCO_DOMAIN_HOME -Dcom.inconcert.icjava.mimetypes=$TIBCO_TRA_HOME/config/IcJavaMIMETypes.txt"

ACTION=%ACTION%

export LD_LIBRARY_PATH SHLIB_PATH LIBPATH CLASSPATH JAVA_OPTS ACTION

# OS specific support.  $var _must_ be set to either true or false.
cygwin=false
case "`uname`" in
CYGWIN*) cygwin=true;;
esac

# resolve links - $0 may be a softlink
PRG="$0"

while [ -h "$PRG" ]; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '.*/.*' > /dev/null; then
    PRG="$link"
  else
    PRG=`dirname "$PRG"`/"$link"
  fi
done

# For Cygwin, ensure paths are in UNIX format before anything is touched
if $cygwin; then
  [ -n "$JAVA_HOME" ] && JAVA_HOME=`cygpath --unix "$JAVA_HOME"`
  [ -n "$CATALINA_HOME" ] && CATALINA_HOME=`cygpath --unix "$CATALINA_HOME"`
  [ -n "$CATALINA_BASE" ] && CATALINA_BASE=`cygpath --unix "$CATALINA_BASE"`
  [ -n "$CLASSPATH" ] && CLASSPATH=`cygpath --path --unix "$CLASSPATH"`
  [ -n "$JSSE_HOME" ] && JSSE_HOME=`cygpath --path --unix "$JSSE_HOME"`
fi

BASEDIR="$CATALINA_HOME"

_RUNJAVA=$JAVA_HOME/bin/java

CLASSPATH="$CLASSPATH"
# Add on extra jar files to CLASSPATH
if [ -n "$JSSE_HOME" ]; then
  CLASSPATH="$CLASSPATH":"$JSSE_HOME"/lib/jcert.jar:"$JSSE_HOME"/lib/jnet.jar:"$JSSE_HOME"/lib/jsse.jar
fi
CLASSPATH="$CLASSPATH":"$CATALINA_HOME"/bin/bootstrap.jar

if [ -z "$CATALINA_BASE" ] ; then
  CATALINA_BASE="$CATALINA_HOME"
fi

if [ -z "$CATALINA_TMPDIR" ] ; then
  # Define the java.io.tmpdir to use for Catalina
  CATALINA_TMPDIR="$CATALINA_BASE"/temp
fi

# For Cygwin, switch paths to Windows format before running java
if $cygwin; then
  JAVA_HOME=`cygpath --path --windows "$JAVA_HOME"`
  CATALINA_HOME=`cygpath --path --windows "$CATALINA_HOME"`
  CATALINA_BASE=`cygpath --path --windows "$CATALINA_BASE"`
  CATALINA_TMPDIR=`cygpath --path --windows "$CATALINA_TMPDIR"`
  CLASSPATH=`cygpath --path --windows "$CLASSPATH"`
  JSSE_HOME=`cygpath --path --windows "$JSSE_HOME"`
fi

# ----- Execute The Requested Command -----------------------------------------

echo "Using CATALINA_BASE:   $CATALINA_BASE"
echo "Using CATALINA_HOME:   $CATALINA_HOME"
echo "Using CATALINA_TMPDIR: $CATALINA_TMPDIR"
echo "Using JAVA_HOME:       $JAVA_HOME"

	if [ ! -d "$CATALINA_BASE"/logs ] 
	then
		mkdir "$CATALINA_BASE"/logs
	fi
  touch "$CATALINA_BASE"/logs/catalina.out
  if [ "$1" = "-security" ] ; then
    echo "Using Security Manager"
    shift
    "$_RUNJAVA" $JAVA_OPTS $CATALINA_OPTS \
      -Djava.endorsed.dirs="$JAVA_ENDORSED_DIRS" -classpath "$CLASSPATH" \
      -Djava.security.manager \
      -Djava.security.policy=="$CATALINA_BASE"/conf/catalina.policy \
      -Dcatalina.base="$CATALINA_BASE" \
      -Dcatalina.home="$CATALINA_HOME" \
      -Djava.io.tmpdir="$CATALINA_TMPDIR" \
      org.apache.catalina.startup.Bootstrap -config $CONFIG_FILE $ACTION \
      >> "$CATALINA_BASE"/logs/catalina.out 2>&1 &

      if [ ! -z "$CATALINA_PID" ]; then
        echo $! > $CATALINA_PID
      fi      
  else
    "$_RUNJAVA" $JAVA_OPTS $CATALINA_OPTS \
      -Djava.endorsed.dirs="$JAVA_ENDORSED_DIRS" -classpath "$CLASSPATH" \
      -Dcatalina.base="$CATALINA_BASE" \
      -Dcatalina.home="$CATALINA_HOME" \
      -Djava.io.tmpdir="$CATALINA_TMPDIR" \
      org.apache.catalina.startup.Bootstrap -config $CONFIG_FILE $ACTION \
      | tee "$CATALINA_BASE"/logs/catalina.out 2>&1

      if [ ! -z "$CATALINA_PID" ]; then
        echo $! > $CATALINA_PID
      fi      
  fi
