#!/bin/sh
# start of domainUtility modifications
SERVER_DIRECTORY=%SERVER_DIRECTORY%
# end of domainUtility modifications

${SERVER_DIRECTORY}/start
