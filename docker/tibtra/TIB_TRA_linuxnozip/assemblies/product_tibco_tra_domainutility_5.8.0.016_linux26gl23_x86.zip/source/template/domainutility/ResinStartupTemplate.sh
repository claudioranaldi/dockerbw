#! /bin/sh
#
# httpd.sh can be called like apachectl
#
# httpd.sh         -- execs the web server in the foreground
# httpd.sh start   -- starts the web server in the background
# httpd.sh stop    -- stops the web server
# httpd.sh restart -- restarts the web server
#
# httpd.sh will return a status code if the wrapper detects an error, but
# some errors, like bind exceptions or Java errors, are not detected.
#
# Customized arguments, e.g. -resin_home or -java_home or -pid.
#
# -pid <pidfile>         -- use a non-default pid file
#                           (useful for multiple servers)
# -java_home <java_home> -- use a non-default Java home
# -stdout <filename>     -- stdout message log
# -stderr <filename>     -- stderr message log
# -native                -- force native threads
# -green                 -- force green threads
# -verbose               -- prints Java arguments before starting.
# -no-auto-restart       -- disable automatic server restart
#                        -- (this only appled to start and restart)
#
# This script can be used as a Linux boot script in init.d.  You'll need to
# configure JAVA_HOME and RESIN_HOME directly.
#
# chkconfig: 345 86 14
# description: Resin is a servlet web server.
# processname: wrapper.pl
#
# To install, you'll need to configure JAVA_HOME and RESIN_HOME and
# copy httpd.sh to /etc/rc.d/init.d as resin.  Then
# use "unix# /sbin/chkconfig resin on"
#
#
# You can predefine JAVA_HOME and RESIN_HOME
#
# JAVA_HOME=/usr/java
# export JAVA_HOME
#


RESIN_HOME=%RESIN_HOME%
CONFIG_FILE=%CONFIG_FILE%
TIBCO_TRA_HOME=%TIBCO_TRA_HOME%
TIBCO_DOMAIN_NAME=%TIBCO_DOMAIN_NAME%
TIBCO_DOMAIN_HOME=%TIBCO_DOMAIN_HOME%
TIBCO_RV_HOME=%TIBCO_RV_HOME%
TIBCO_HAWK_HOME=%TIBCO_HAWK_HOME%
TIBCO_TPCL_HOME=%TIBCO_TPCL_HOME%
TIBCO_TPCL_LIB_NAME=%TIBCO_TPCL_LIB_NAME%
JAVA_HOME=%JAVA_HOME%
SERVER_ARGS=%SERVER_ARGS%


export RESIN_HOME
export CONFIG_FILE
export TIBCO_TRA_HOME
export TIBCO_DOMAIN_NAME
export TIBCO_DOMAIN_HOME
export TIBCO_RV_HOME
export TIBCO_HAWK_HOME
export TIBCO_TPCL_HOME
export TIBCO_TPCL_LIB_NAME
export JAVA_HOME
export SERVER_ARGS

CMD_LINE_ARGS=-conf "%CONFIG_FILE%"
export CMD_LINE_ARGS
JAVA_OPTS=-DTIBCO_DOMAIN_NAME="%TIBCO_DOMAIN_NAME%" -DTIBCO_DOMAIN_HOME="%TIBCO_DOMAIN_HOME%" -Dcom.inconcert.icjava.mimetypes=%TIBCO_TRA_HOME%\config\IcJavaMIMETypes.txt -Djava.library.path=%TIBCO_RV_HOME%\bin;%TIBCO_TRA_HOME%\hotfix\icjava\6.2\bin;%TIBCO_TRA_HOME%\icjava\6.2\bin;%TIBCO_TPCL_HOME%\bin;%TIBCO_TRA_HOME%\hotfix\bin;%TIBCO_TRA_HOME%\bin;%TIBCO_RV_HOME%\lib 
export JAVA_OPTS
CP=.
for i in %JAVA_HOME%\lib\tools.jar %TIBCO_TRA_HOME%\hotfix\icjava\6.2\lib\icjava621.jar %TIBCO_TRA_HOME%\icjava\6.2\lib\icjava621.jar %TIBCO_TRA_HOME%\hotfix\lib\TIBCrypt.jar %TIBCO_TRA_HOME%\lib\TIBCrypt.jar %TIBCO_TRA_HOME%\..\dependency\default\%TIBCO_TPCL_LIB_NAME% %TIBCO_TRA_HOME%\..\dependency\default\HAWKlib.jar %TIBCO_TRA_HOME%\lib\TIBCOjms.jar %TIBCO_TRA_HOME%\..\dependency\default\RVlib.jar ; do
   CP=${CP}:$i
done





#
# Extra arguments to Java.  If you're passing arguments to the JVM, you'll
# need to use -Jxxx.  For example, args="-J-ms48m".  You can modify
# the pid file with args="-pid server-a.pid"
#
args="-J-server -J-mx200m -J-ms64m -classpath ${CP} ${JAVA_OPTS} ${CMD_LINE_ARGS} ${SERVER_ARGS}"
#
# class to start
#
class=com.caucho.server.http.HttpServer
#
# name of the server
#
name=httpd
#
# location of perl executable
#
perl=perl

#
# trace script and simlinks to find thw wrapper
#
script=`/bin/ls -l $0 | awk '{ print $NF; }'`

while test -h "$script"
do
  script=`/bin/ls -l $script | awk '{ print $NF; }'`
done

bin=`dirname $script`

exec $perl $bin/wrapper.pl -chdir -name "$name" -class "$class" $args $*
