// ExternalTypes.h
// Copyright 2003 by TIBCO Software Inc.
// ALL RIGHTS RESERVED


#ifndef _ExternalTypes_h_
	#define _ExternalTypes_h_


typedef enum {
				SVC_UNINITIALIZED=0,
				SVC_INITIALIZING=1,
				SVC_RUNNING=2,
				SVC_STOPPING=3,
				SVC_STOPPED=4
} SERVICE_STATE;


typedef int (*APP_MAIN_FN_PTR)( int, char ** );
typedef void (*APP_STOP_FN_PTR)();
typedef void (*APP_SERVICE_STATE_FN_PTR)( SERVICE_STATE );
typedef void (*APP_REGISTER_ENTRY_POINTS_FN_PTR)( APP_SERVICE_STATE_FN_PTR );


#endif // _ExternalTypes_h_

