// Types.h
// Copyright 2001-2003 by TIBCO Software Inc.
// ALL RIGHTS RESERVED


#ifndef _Types_h_
	#define _Types_h_

// This picks up SERVICE_STATE and the related function pointers for 
// loading C++ shared libraries.
#include "ExternalTypes.h"


typedef enum {
		INSTALL_NEW_NT_SERVICE
		,UNINSTALL_EXISTING_NT_SERVICE
		,UPDATE_EXISTING_NT_SERVICE
		,START_EXISTING_NT_SERVICE
		,STOP_RUNNING_NT_SERVICE
		,RESTART_RUNNING_NT_SERVICE
		,QUERY_RUNNING_NT_SERVICE
		,RUN_AS_NT_SERVICE
		,RUN_AS_CONSOLE_APPLICATION
		,VERSION
		,HELP
		,START_EXISTING_NT_SERVICE_SYNC
} WrapperState;


typedef enum {
				SQR_UNKNOWN,
				SQR_ACCESS_DENIED,
				SQR_INVALID_NAME,
				SQR_INVALID_HANDLE,
				SQR_DOES_NOT_EXIST,
            SQR_UNINITIALIZED,
				SQR_INITIALIZING,
				SQR_RUNNING,
				SQR_STOPPING,
				SQR_STOPPED
} SVC_QUERY_RESULT;


//========================
// parser support
//========================
typedef enum {
	SS_DOING_NOTHING
	,SS_DOING_COMMENT
	,SS_DOING_KEY
	,SS_DOING_VALUE
} SCANNER_STATE;
//=====================



//========================
// formal boolean definition for portability - Sun CC does not support bool
#if defined( WIN32 )
	// do nothing
#else
#       ifndef bool
#               define bool unsigned char
#       endif
#       ifndef true
#               define true    ((unsigned char)1)
#       endif
#       ifndef false
#               define false   ((unsigned char)0)
#       endif
#endif
//========================


//========================
#if ( defined WIN32 )
#  include <assert.h>
#  if (defined _DEBUG )
#     define WERRORS_ASSERT(exp) assert(exp)
#  else
#     define WERRORS_ASSERT(exp)
#  endif
#else
#  define WERRORS_ASSERT(exp)
#endif
//========================


#endif // _Types_h_

