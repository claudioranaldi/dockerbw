#ifndef _Wrapper_Methods_h_
	#define _Wrapper_Methods_h_
	
	
#include "Types.h"


extern int LaunchWrapper( int argc, char * * argv, APP_MAIN_FN_PTR pAppMainFn, APP_STOP_FN_PTR pAppStopFn );

extern void SetServiceState( SERVICE_STATE state );


#endif		// _Wrapper_Methods_h_
