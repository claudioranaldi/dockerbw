function  WWHBookData_Files(P)
{
P.fA("TIBCO Runtime Agent\u2122","title.1.1.htm");
P.fA("Important Information","copyrigh.htm");
P.fA("Figures","LOF.htm");
P.fA("Preface","preface.3.1.htm");
P.fA("Changes from the Previous Release of this Guide","preface.3.2.htm");
P.fA("Related Documentation","preface.3.3.htm");
P.fA("Typographical Conventions","preface.3.4.htm");
P.fA("Connecting with TIBCO Resources","preface.3.5.htm");
P.fA("Concepts","cluster.4.01.htm");
P.fA("Overview","cluster.4.02.htm");
P.fA("Failover Cluster Characteristics","cluster.4.03.htm");
P.fA("Cluster Support Limitations","cluster.4.04.htm");
P.fA("Placing TIBCO Applications into a Cluster Scenarios","cluster.4.05.htm");
P.fA("Installing the Software Into a Cluster","cluster.4.06.htm");
P.fA("Overview","cluster.4.07.htm");
P.fA("Creating a Cluster Group","cluster.4.08.htm");
P.fA("Installing TIBCO Runtime Agent on the Active Node","cluster.4.09.htm");
P.fA("Installing TIBCO Administrator on the Active Node","cluster.4.10.htm");
P.fA("Register the Services with the Cluster","cluster.4.11.htm");
P.fA("Configure the Second Node","cluster.4.12.htm");
P.fA("Adding a TIBCO Application as a Service to the Cluster","cluster.4.13.htm");
P.fA("Adding a TIBCO Application as an Application to a Cluster","cluster.4.14.htm");
P.fA("Installing TIBCO Software Onto a Shared Drive","cluster.4.15.htm");
P.fA("Verify the Installation","cluster.4.16.htm");
P.fA("Installed Files","cluster.4.17.htm");
P.fA("Deploying and Starting Applications Under Cluster Control","cluster.4.18.htm");
P.fA("Redeploying Applications","cluster.4.19.htm");
P.fA("Forcing Redeployment of an NT Service","cluster.4.20.htm");
P.fA("Starting and Stopping Applications Managed by Cluster Software","cluster.4.21.htm");
P.fA("Removing Orphaned Services","cluster.4.22.htm");
}
