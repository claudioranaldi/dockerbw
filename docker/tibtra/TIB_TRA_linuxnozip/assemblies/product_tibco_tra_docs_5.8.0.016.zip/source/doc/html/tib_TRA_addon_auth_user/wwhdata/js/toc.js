function  WWHBookData_AddTOCEntries(P)
{
var A=P.fN("Preface","2");
var B=A.fN("Changes from the Previous Release of this Guide","3");
B=A.fN("Related Documentation","4");
var C=B.fN("TIBCO Runtime Agent Documentation","4#40347");
C=B.fN("Other TIBCO Product Documentation","4#24887");
B=A.fN("Typographical Conventions","5");
B=A.fN("Connecting with TIBCO Resources","6");
C=B.fN("How to Join TIBCOmmunity","6#39327");
C=B.fN("How to Access All TIBCO Documentation","6#39357");
C=B.fN("How to Contact TIBCO Support","6#39302");
A=P.fN("Chapter\u00a01 Using the TIBCO Runtime Agent Authentication API","7");
B=A.fN("Feature Overview","8");
B=A.fN("API Overview","9");
B=A.fN("Getting Started with the API","10");
C=B.fN("Compiling Programs","10#1675238");
C=B.fN("Running Programs","10#1675418");
C=B.fN("Running the Samples","10#1674648");
C=B.fN("Using the API","10#1673396");
B=A.fN("Common Aspects of the API","11");
C=B.fN("Objects and Factory","11#1676606");
C=B.fN("AuthenticationSubject","11#1676609");
C=B.fN("RoleMembershipConfig and RoleMembership","11#1676612");
C=B.fN("AuthUtils","11#1676620");
B=A.fN("Best Practices","12");
C=B.fN("General Tips","12#1676640");
}
