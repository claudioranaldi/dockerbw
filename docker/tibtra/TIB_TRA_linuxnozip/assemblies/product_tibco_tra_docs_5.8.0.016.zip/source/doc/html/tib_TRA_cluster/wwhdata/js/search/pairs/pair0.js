function FileData_Pairs(x)
{
x.t("installing","cluster");
x.t("2012","tibco");
x.t("cluster","software");
x.t("software","release");
x.t("software","tibco");
x.t("release","5.8.0");
x.t("tibco","software");
x.t("tibco","runtime");
x.t("5.8.0","november");
x.t("agent","installing");
x.t("agent","tibco");
x.t("runtime","agent");
x.t("november","2012");
}
