// Copyright (c) 2000-2012 Quadralay Corporation.  All rights reserved.
//

// Load book TOC
//
WWHFrame.WWHOutline.fInitLoadBookTOC(WWHBookData_AddTOCEntries);
