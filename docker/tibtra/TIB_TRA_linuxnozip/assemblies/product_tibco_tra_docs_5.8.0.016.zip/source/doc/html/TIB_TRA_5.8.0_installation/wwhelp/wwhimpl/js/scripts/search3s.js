// Copyright (c) 2000-2012 Quadralay Corporation.  All rights reserved.
//

// Increment book index
//
WWHFrame.WWHSearch.mBookIndex++;
