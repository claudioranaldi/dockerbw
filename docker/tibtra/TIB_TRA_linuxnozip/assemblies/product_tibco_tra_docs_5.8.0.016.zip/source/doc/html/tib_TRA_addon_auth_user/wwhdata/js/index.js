function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("API Overview",new Array("9"));
A=P.fA("C",null,null,"002");
B=A.fA("changes from the previous release of TIBCO Runtime Agent Authentication API User\u2019s Guide",new Array("3"));
B=A.fA("Compiling Programs",new Array("10#1675238"));
B=A.fA("customer support",new Array("6#39302"));
A=P.fA("D",null,null,"002");
B=A.fA("Documentation",new Array("4"));
B=A.fA("Documentation, Other TIBCO Product",new Array("4#24887"));
B=A.fA("Documentation, TIBCO Runtime Agent",new Array("4#40347"));
A=P.fA("E",null,null,"002");
B=A.fA("ENV_NAME",new Array("5#41053"));
A=P.fA("G",null,null,"002");
B=A.fA("Getting Started with the API",new Array("10"));
A=P.fA("R",null,null,"002");
B=A.fA("Running Programs",new Array("10#1675418"));
B=A.fA("Running the Samples",new Array("10#1674648"));
A=P.fA("S",null,null,"002");
B=A.fA("support, contacting",new Array("6#39302"));
A=P.fA("T",null,null,"002");
B=A.fA("technical support",new Array("6#39302"));
B=A.fA("TIBCO_HOME",new Array("5#37287"));
B=A.fA("TRA_HOME",new Array("5#37288"));
A=P.fA("U",null,null,"002");
B=A.fA("Using the API",new Array("10#1673396"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 2;
}
