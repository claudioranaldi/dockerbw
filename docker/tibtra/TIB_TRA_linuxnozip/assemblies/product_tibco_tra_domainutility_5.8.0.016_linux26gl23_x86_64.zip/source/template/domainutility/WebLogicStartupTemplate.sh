#!/bin/sh
# ****************************************************************************
# This script is used to start WebLogic Server for the domain in the current 
# working directory.  This script simply sets the SERVER_NAME variable 
# and calls the startWLS.sh script under ${WL_HOME}/server/bin.
#
# Other variables that startWLS takes are:
#
# PRODUCTION_MODE - Set to true for production mode servers, false for
#                   development mode
# JAVA_OPTIONS    - Java command-line options for running the server. (These
#                   will be tagged on to the end of the JAVA_VM and MEM_ARGS)
# JAVA_VM         - The java arg specifying the VM to run.  (i.e. -server,
#                   -hotspot, etc.)
# MEM_ARGS        - The variable to override the standard memory arguments
#                   passed to java
#
# ****************************************************************************

# Set Production Mode.  When this is set to true, the server starts up in 
# production mode.  When set to false, the server starts up in development 
# mode.  If it is not set, it will default to false.
PRODUCTION_MODE="true"

# Set JAVA_OPTIONS to the java flags you want to pass to the vm.  If there 
# are more than one, include quotes around them.  For instance: 
# JAVA_OPTIONS="-Dweblogic.attribute=value -Djava.attribute=value"

# start of domainUtility modifications
SERVER_NAME=%SERVER_NAME%
WEBLOGIC_HOME=%WEBLOGIC_HOME%
DOMAIN_DIRECTORY=%DOMAIN_DIRECTORY%
TIBCO_TRA_HOME=%TIBCO_TRA_HOME%
TIBCO_DOMAIN_NAME=%TIBCO_DOMAIN_NAME%
TIBCO_DOMAIN_HOME=%TIBCO_DOMAIN_HOME%
TIBCO_RV_HOME=%TIBCO_RV_HOME%
TIBCO_HAWK_HOME=%TIBCO_HAWK_HOME%
TIBCO_TPCL_HOME=%TIBCO_TPCL_HOME%
TIBCO_TPCL_LIB_NAME=%TIBCO_TPCL_LIB_NAME%
# end of domainUtility modifications

WL_HOME=${WEBLOGIC_HOME}
JAVA_VENDOR="BEA"
JAVA_HOME=${WL_HOME}/../jdk142_05

export JAVA_VENDOR SERVER_NAME WEBLOGIC_HOME DOMAIN_DIRECTORY TIBCO_TRA_HOME TIBCO_DOMAIN_NAME TIBCO_DOMAIN_HOME TIBCO_RV_HOME TIBCO_HAWK_HOME TIBCO_TPCL_HOME JAVA_HOME WL_HOME

. ${WL_HOME}/common/bin/commEnv.sh

# ----------------------------------------------------------------------------------
# User should not change the values for these properties. This section is based on
# installation of TIBCO products.

LD_LIBRARY_PATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:${WEBLOGIC_HOME}/server/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$LD_LIBRARY_PATH

SHLIB_PATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:${WEBLOGIC_HOME}/server/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$SHLIB_PATH

LIBPATH=$TIBCO_TRA_HOME/hotfix/icjava/6.2/bin:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib:$TIBCO_TRA_HOME/hotfix/bin:$TIBCO_TRA_HOME/icjava/6.2/bin:$TIBCO_TRA_HOME/icjava/6.2/lib:$TIBCO_TRA_HOME/bin:$TIBCO_RV_HOME/bin:$TIBCO_HAWK_HOME/bin:${WEBLOGIC_HOME}/server/bin:$TIBCO_TPCL_HOME/hotfix/bin:$TIBCO_TPCL_HOME/bin:$TIBCO_RV_HOME/lib:$LIBPATH

TIBCO_CLASSPATH=$JAVA_HOME/lib/tools.jar:$TIBCO_TRA_HOME/hotfix/icjava/6.2/lib/icjava621.jar:$TIBCO_TRA_HOME/icjava/6.2/lib/icjava621.jar:$TIBCO_TRA_HOME/hotfix/lib/TIBCrypt.jar:$TIBCO_TRA_HOME/lib/TIBCrypt.jar:$TIBCO_TRA_HOME/../dependency/default/$TIBCO_TPCL_LIB_NAME:$TIBCO_TRA_HOME/../dependency/default/HAWKlib.jar:$TIBCO_TRA_HOME/lib/TIBCOjms.jar:$TIBCO_TRA_HOME/../dependency/default/RVlib.jar:
CLASSPATH="${WEBLOGIC_CLASSPATH}:${POINTBASE_CLASSPATH}:${JAVA_HOME}/jre/lib/rt.jar:${WL_HOME}/server/lib/webservices.jar:${CLASSPATH}:${TIBCO_CLASSPATH}"

JAVA_OPTIONS="-Dweblogic.security.SSL.trustedCAKeyStore=$WEBLOGIC_HOME/server/lib/cacerts -DTIBCO_DOMAIN_NAME=$TIBCO_DOMAIN_NAME -DTIBCO_DOMAIN_HOME=$TIBCO_DOMAIN_HOME -DLANG=$LANG -Dcom.inconcert.icjava.mimetypes=$TIBCO_TRA_HOME/config/IcJavaMIMETypes.txt"

export LD_LIBRARY_PATH SHLIB_PATH LIBPATH CLASSPATH JAVA_OPTIONS

WLS_USER=
WLS_PW=
export WLS_USER WLS_PW

# Set JAVA_VM to the java virtual machine you want to run.  For instance:
# JAVA_VM="-server"
JAVA_VM=""

# Set MEM_ARGS to the memory args you want to pass to java.  For instance:
# MEM_ARGS=""
MEM_ARGS="-Xms128m -Xmx256m"

cd $DOMAIN_DIRECTORY

echo "."
echo "CLASSPATH=${CLASSPATH}"
echo "."
echo "PATH=${PATH}"
echo "."
echo "***************************************************"
echo "*  To start WebLogic Server, use a username and   *"
echo "*  password assigned to an admin-level user.  For *"
echo "*  server administration, use the WebLogic Server *"
echo "*  console at http://[hostname]:[port]/console    *"
echo "***************************************************"

${JAVA_HOME}/bin/java ${JAVA_VM} ${MEM_ARGS} ${JAVA_OPTIONS} -Dweblogic.Name=${SERVER_NAME} -Dweblogic.ProductionModeEnabled=${PRODUCTION_MODE} -Djava.security.policy="${WL_HOME}/server/lib/weblogic.policy" weblogic.Server
